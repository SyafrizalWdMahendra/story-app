import routes from "../routes/routes";
import { getActiveRoute } from "../routes/url-parser";
import Auth from "./services/auth";

class App {
  #content = null;
  #drawerButton = null;
  #navigationDrawer = null;
  #auth = null;
  #skipLink = null;

  constructor({ navigationDrawer, drawerButton, content }) {
    this.#content = content;
    this.#drawerButton = drawerButton;
    this.#navigationDrawer = navigationDrawer;
    this.#auth = new Auth();
    this.#skipLink = document.querySelector(".skip-to-content");

    this._setupDrawer();
    this._setupAuth();
    this._setupSkipToContent();
  }

  _setupDrawer() {
    this.#drawerButton.addEventListener("click", () => {
      this.#navigationDrawer.classList.toggle("open");
    });

    document.body.addEventListener("click", (event) => {
      if (
        !this.#navigationDrawer.contains(event.target) &&
        !this.#drawerButton.contains(event.target)
      ) {
        this.#navigationDrawer.classList.remove("open");
      }

      this.#navigationDrawer.querySelectorAll("a").forEach((link) => {
        if (link.contains(event.target)) {
          this.#navigationDrawer.classList.remove("open");
        }
      });
    });
  }

  _setupAuth() {
    this.#auth.onAuthStateChanged(() => this._updateNavigationUI());

    this._updateNavigationUI();
  }

  _updateNavigationUI() {
    const loginLink = document.getElementById("loginLink");
    const logoutLink = document.getElementById("logoutLink");
    const registerLink = document.getElementById("registerLink");

    if (this.#auth.isAuthenticated) {
      loginLink.style.display = "none";
      registerLink.style.display = "none";
      logoutLink.style.display = "block";
    } else {
      loginLink.style.display = "block";
      registerLink.style.display = "block";
      logoutLink.style.display = "none";
    }
  }

  _setupSkipToContent() {
    if (!this.#skipLink) return;

    const updateSkipLink = () => {
      const currentHash = window.location.hash || "#/";
      this.#skipLink.href = `${currentHash}#main-content`;
    };

    updateSkipLink();

    window.addEventListener("hashchange", updateSkipLink);

    this.#skipLink.addEventListener("click", (e) => {
      e.preventDefault();
      this.#content.focus();
    });
  }

  async renderPage() {
    const url = getActiveRoute();
    const route = routes[url];

    if (!route) {
      window.location.hash = "/";
      return;
    }

    if (route.needAuth && !this.#auth.checkAuth()) {
      window.location.hash = "/login";
      return;
    }

    if (route.needGuest && this.#auth.checkAuth()) {
      window.location.hash = "/";
      return;
    }

    if (!document.startViewTransition) {
      return this.#renderPageWithoutTransition(route);
    }

    document.startViewTransition(async () => {
      await this.#renderPageWithoutTransition(route);
      if (window.location.hash.endsWith("#main-content")) {
        this.#content.focus();
      }
    });
  }

  async #renderPageWithoutTransition(route) {
    try {
      const page = route.page(this.#auth);
      this.#content.innerHTML = await page.render();
      await page.afterRender();
      this._updateNavigationUI();
    } catch (error) {
      console.error("Page rendering error:", error);
      window.location.hash = "/";
    }
  }
}

export default App;
