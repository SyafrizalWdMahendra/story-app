export default class Auth {
  constructor() {
    this.isAuthenticated = this.checkAuth();
    this.listeners = [];
  }

  onAuthStateChanged(callback) {
    this.listeners.push(callback);
  }

  _notifyListeners() {
    this.listeners.forEach((callback) => callback());
  }

  login(token, remember = true) {
    if (remember) {
      localStorage.setItem("authToken", token);
    } else {
      sessionStorage.setItem("authToken", token);
    }
    this.isAuthenticated = true;
    this._notifyListeners();
  }

  logout() {
    localStorage.removeItem("authToken");
    sessionStorage.removeItem("authToken");
    this.isAuthenticated = false;
    this._notifyListeners();
    return Promise.resolve();
  }

  checkAuth() {
    this.isAuthenticated = !!(
      localStorage.getItem("authToken") || sessionStorage.getItem("authToken")
    );
    return this.isAuthenticated;
  }

  getToken() {
    return (
      localStorage.getItem("authToken") || sessionStorage.getItem("authToken")
    );
  }
}
